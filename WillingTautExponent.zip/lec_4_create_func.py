def mult_func(a):
  x=3*a
  return x

tmp=mult_func(4) 
print(tmp)

print(mult_func(10))

print(mult_func(' good '))

def print_func(a):
 print (a)

print_func('Hello')