x0=10 #глобальная переменная
def moove(t):
 x=x0*t #локальная переменная 
 return x
 
print(moove(3))

x='GOOD'
def my_func():
  x='Bad'
  print(x)
my_func()

print(x)










