#import lec_4_create_func
import lec_4_scope
import lec_4_arg
import lec_4_return
import lec_4_example


